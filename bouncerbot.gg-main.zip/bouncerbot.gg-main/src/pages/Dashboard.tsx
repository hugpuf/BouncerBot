import { motion } from "framer-motion";
import { BouncerMascot } from "@/components/BouncerMascot";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Plus, Users, CheckCircle, DoorOpen } from "lucide-react";
import { Navbar } from "@/components/landing/Navbar";

const stats = [
  { label: "Let in", value: "1,247", icon: Users, color: "text-mint" },
  { label: "Conversion", value: "87%", icon: CheckCircle, color: "text-lavender" },
  { label: "Doors open", value: "3", icon: DoorOpen, color: "text-peach" },
];

const venues = [
  { name: "Design Community", status: "active", members: 842, flows: 2 },
  { name: "Dev Collective", status: "active", members: 356, flows: 1 },
  { name: "Creator DAO", status: "inactive", members: 49, flows: 1 },
];

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16 container mx-auto px-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-pixel text-lg text-foreground mb-1">The Clipboard</h1>
            <p className="text-sm text-muted-foreground">Your venues at a glance.</p>
          </div>
          <div className="flex items-center gap-4">
            <BouncerMascot pose="nod" size={48} animate={false} />
            <Button className="gradient-mint-lavender text-primary-foreground font-pixel text-[9px] gap-2">
              <Plus className="w-4 h-4" /> New Venue
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-3 gap-4 mb-10">
          {stats.map((s) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-xl p-5 border border-border"
            >
              <div className="flex items-center gap-2 mb-2">
                <s.icon className={`w-4 h-4 ${s.color}`} />
                <span className="text-xs text-muted-foreground">{s.label}</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Venues */}
        <h2 className="font-pixel text-xs text-foreground mb-4">Your Venues</h2>
        <div className="space-y-3">
          {venues.map((v, i) => (
            <motion.div
              key={v.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-xl p-5 border border-border flex items-center justify-between hover:border-mint/30 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <div className={`w-3 h-3 rounded-full ${v.status === "active" ? "bg-mint" : "bg-muted-foreground"}`} />
                <div>
                  <p className="font-semibold text-sm text-foreground">{v.name}</p>
                  <p className="text-xs text-muted-foreground">{v.members} members · {v.flows} flows</p>
                </div>
              </div>
              <Link to="/flow-builder">
                <Button variant="outline" size="sm" className="text-xs">
                  Edit Door Policy
                </Button>
              </Link>
            </motion.div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
