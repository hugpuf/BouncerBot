import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Navbar } from "@/components/landing/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { BouncerMascot } from "@/components/BouncerMascot";
import {
  Type, List, ListChecks, Link2, Mail, GripVertical,
  Plus, Trash2, ChevronDown, Settings2, GitBranch,
  X, Save, Eye, Pencil
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────
type QuestionType = "text" | "select" | "multi" | "url" | "email";

interface SelectOption {
  id: string;
  label: string;
  emoji?: string;
}

interface ConditionalBranch {
  triggerOptionId: string;
  targetQuestionId: string;
}

interface FlowQuestion {
  id: string;
  type: QuestionType;
  text: string;
  required: boolean;
  skippable: boolean;
  options: SelectOption[];
  validation?: { min?: number; max?: number; pattern?: string };
  branches: ConditionalBranch[];
}

const questionTypes: { type: QuestionType; icon: typeof Type; label: string; color: string }[] = [
  { type: "text", icon: Type, label: "Text Input", color: "text-mint" },
  { type: "select", icon: List, label: "Single Select", color: "text-lavender" },
  { type: "multi", icon: ListChecks, label: "Multi-Select", color: "text-peach" },
  { type: "url", icon: Link2, label: "URL", color: "text-baby-blue" },
  { type: "email", icon: Mail, label: "Email", color: "text-pastel-pink" },
];

const uid = () => Math.random().toString(36).slice(2, 9);

// ── Default flow mirroring the bot ─────────────────────────
const defaultFlow: FlowQuestion[] = [
  {
    id: "q1", type: "text", text: "What is your full name?", required: true, skippable: false,
    options: [], validation: { min: 2, max: 32 }, branches: [],
  },
  {
    id: "q2", type: "select", text: "What best describes you?", required: true, skippable: false,
    options: [
      { id: "o1", label: "Academic Researcher", emoji: "🎓" },
      { id: "o2", label: "Industry Researcher", emoji: "🏢" },
      { id: "o3", label: "Software Developer", emoji: "💻" },
      { id: "o4", label: "Something Else", emoji: "✨" },
    ],
    branches: [{ triggerOptionId: "o4", targetQuestionId: "q3" }],
  },
  {
    id: "q3", type: "text", text: "Tell me more — what's your role?", required: true, skippable: false,
    options: [], branches: [],
  },
  {
    id: "q4", type: "text", text: "What organization are you from?", required: true, skippable: false,
    options: [], branches: [],
  },
  {
    id: "q5", type: "url", text: "What's your organization's website?", required: false, skippable: true,
    options: [], branches: [],
  },
  {
    id: "q6", type: "multi", text: "Which simulation domains interest you?", required: false, skippable: true,
    options: [
      { id: "d1", label: "Structural & Mechanical (FEA)", emoji: "🔩" },
      { id: "d2", label: "Fluid Dynamics (CFD)", emoji: "🌊" },
      { id: "d3", label: "Electromagnetics (EM)", emoji: "⚡" },
      { id: "d4", label: "Systems & Process", emoji: "⚙️" },
      { id: "d5", label: "Motion Simulation", emoji: "🎯" },
      { id: "d6", label: "Multiphysics", emoji: "🔬" },
    ],
    branches: [],
  },
  {
    id: "q7", type: "email", text: "What's your email address?", required: false, skippable: true,
    options: [], branches: [],
  },
  {
    id: "q8", type: "url", text: "What's your LinkedIn profile URL?", required: false, skippable: true,
    options: [], branches: [],
  },
];

// ── Component ──────────────────────────────────────────────
const FlowBuilder = () => {
  const [questions, setQuestions] = useState<FlowQuestion[]>(defaultFlow);
  const [selectedId, setSelectedId] = useState<string | null>("q1");
  const [previewStep, setPreviewStep] = useState(0);
  const [previewAnswers, setPreviewAnswers] = useState<Record<string, string>>({});

  const selected = questions.find(q => q.id === selectedId) ?? null;

  const updateQuestion = useCallback((id: string, patch: Partial<FlowQuestion>) => {
    setQuestions(prev => prev.map(q => q.id === id ? { ...q, ...patch } : q));
  }, []);

  const addQuestion = (type: QuestionType) => {
    const newQ: FlowQuestion = {
      id: uid(), type, text: "New question...", required: false, skippable: false,
      options: type === "select" || type === "multi"
        ? [{ id: uid(), label: "Option 1" }, { id: uid(), label: "Option 2" }]
        : [],
      branches: [],
    };
    setQuestions(prev => [...prev, newQ]);
    setSelectedId(newQ.id);
  };

  const removeQuestion = (id: string) => {
    setQuestions(prev => prev.filter(q => q.id !== id));
    if (selectedId === id) setSelectedId(null);
  };

  const addOption = (qId: string) => {
    setQuestions(prev => prev.map(q =>
      q.id === qId
        ? { ...q, options: [...q.options, { id: uid(), label: `Option ${q.options.length + 1}` }] }
        : q
    ));
  };

  const updateOption = (qId: string, oId: string, label: string) => {
    setQuestions(prev => prev.map(q =>
      q.id === qId
        ? { ...q, options: q.options.map(o => o.id === oId ? { ...o, label } : o) }
        : q
    ));
  };

  const removeOption = (qId: string, oId: string) => {
    setQuestions(prev => prev.map(q =>
      q.id === qId
        ? { ...q, options: q.options.filter(o => o.id !== oId), branches: q.branches.filter(b => b.triggerOptionId !== oId) }
        : q
    ));
  };

  const toggleBranch = (qId: string, optionId: string, targetId: string) => {
    setQuestions(prev => prev.map(q => {
      if (q.id !== qId) return q;
      const exists = q.branches.find(b => b.triggerOptionId === optionId);
      if (exists) {
        return { ...q, branches: q.branches.filter(b => b.triggerOptionId !== optionId) };
      }
      return { ...q, branches: [...q.branches, { triggerOptionId: optionId, targetQuestionId: targetId }] };
    }));
  };

  // ── Preview logic ─────────────────────────────────────
  const getVisibleQuestions = (): FlowQuestion[] => {
    const visible: FlowQuestion[] = [];
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      // Check if this question is a branch target that shouldn't show
      const isBranchTarget = questions.some(parent =>
        parent.branches.some(b => b.targetQuestionId === q.id)
      );
      if (isBranchTarget) {
        // Only show if the triggering option was selected
        const parentQ = questions.find(p => p.branches.some(b => b.targetQuestionId === q.id));
        if (parentQ) {
          const branch = parentQ.branches.find(b => b.targetQuestionId === q.id);
          const answer = previewAnswers[parentQ.id];
          if (!branch || answer !== branch.triggerOptionId) continue;
        }
      }
      visible.push(q);
    }
    return visible;
  };

  const visibleQuestions = getVisibleQuestions();
  const currentPreviewQ = visibleQuestions[previewStep];

  const handlePreviewAnswer = (answer: string) => {
    if (!currentPreviewQ) return;
    setPreviewAnswers(prev => ({ ...prev, [currentPreviewQ.id]: answer }));
    if (previewStep < visibleQuestions.length - 1) {
      setPreviewStep(prev => prev + 1);
    }
  };

  const resetPreview = () => {
    setPreviewStep(0);
    setPreviewAnswers({});
  };

  const getTypeIcon = (type: QuestionType) => {
    const qt = questionTypes.find(q => q.type === type);
    return qt ? qt.icon : Type;
  };

  const getTypeColor = (type: QuestionType) => {
    const qt = questionTypes.find(q => q.type === type);
    return qt ? qt.color : "text-muted-foreground";
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Mobile message */}
      <div className="lg:hidden pt-24 pb-16 container mx-auto px-6 text-center">
        <h1 className="font-pixel text-sm text-foreground mb-4">Door Policy Builder</h1>
        <p className="text-muted-foreground">Bouncer works the door on desktop only.</p>
        <p className="text-xs text-muted-foreground mt-2">Switch to desktop to build your flows.</p>
      </div>

      {/* Desktop layout */}
      <div className="hidden lg:flex pt-16 h-screen">
        {/* ── Left sidebar: question types ── */}
        <div className="w-56 bg-card border-r border-border p-4 pt-8 flex-shrink-0">
          <h3 className="font-pixel text-[9px] text-muted-foreground mb-4">ADD QUESTION</h3>
          <div className="space-y-2">
            {questionTypes.map(qt => (
              <button
                key={qt.type}
                onClick={() => addQuestion(qt.type)}
                className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-muted hover:bg-card-hover text-sm text-foreground transition-colors border border-border hover:border-primary/30"
              >
                <qt.icon className={`w-4 h-4 ${qt.color}`} />
                {qt.label}
              </button>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-border">
            <h3 className="font-pixel text-[9px] text-muted-foreground mb-3">FLOW STATS</h3>
            <div className="space-y-2 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Questions</span>
                <span className="text-foreground font-medium">{questions.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Required</span>
                <span className="text-foreground font-medium">{questions.filter(q => q.required).length}</span>
              </div>
              <div className="flex justify-between">
                <span>Branches</span>
                <span className="text-foreground font-medium">{questions.reduce((sum, q) => sum + q.branches.length, 0)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* ── Center canvas ── */}
        <div className="flex-1 p-8 overflow-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-pixel text-sm text-foreground">Door Policy Flow</h2>
            <Button className="gradient-mint-lavender text-primary-foreground font-pixel text-[9px]">
              <Save className="w-3 h-3 mr-1" /> Save & Deploy
            </Button>
          </div>

          <div className="space-y-1 max-w-xl mx-auto">
            {questions.map((q, i) => {
              const Icon = getTypeIcon(q.type);
              const isBranchTarget = questions.some(p => p.branches.some(b => b.targetQuestionId === q.id));

              return (
                <div key={q.id}>
                  <motion.div
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    onClick={() => setSelectedId(q.id)}
                    className={`bg-card rounded-xl p-4 border cursor-pointer transition-all ${
                      selectedId === q.id
                        ? "border-primary/50 shadow-lg shadow-primary/5"
                        : "border-border hover:border-primary/20"
                    } ${isBranchTarget ? "ml-8 border-l-2 border-l-lavender" : ""}`}
                  >
                    <div className="flex items-center gap-3">
                      <GripVertical className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <Icon className={`w-4 h-4 ${getTypeColor(q.type)} flex-shrink-0`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="font-pixel text-[8px] text-muted-foreground">Q{i + 1}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground capitalize">
                            {q.type === "multi" ? "multi-select" : q.type}
                          </span>
                          {q.required && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-primary/10 text-primary">Required</span>
                          )}
                          {q.skippable && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-accent/10 text-accent">Skippable</span>
                          )}
                          {q.branches.length > 0 && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-secondary/10 text-secondary flex items-center gap-1">
                              <GitBranch className="w-3 h-3" /> {q.branches.length} branch{q.branches.length > 1 ? "es" : ""}
                            </span>
                          )}
                          {isBranchTarget && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-secondary/10 text-secondary">Conditional</span>
                          )}
                        </div>
                        <p className="text-sm text-foreground truncate">{q.text}</p>
                        {(q.type === "select" || q.type === "multi") && q.options.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1.5">
                            {q.options.slice(0, 4).map(o => (
                              <span key={o.id} className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                                {o.emoji && `${o.emoji} `}{o.label}
                              </span>
                            ))}
                            {q.options.length > 4 && (
                              <span className="text-[10px] px-1.5 py-0.5 text-muted-foreground">+{q.options.length - 4} more</span>
                            )}
                          </div>
                        )}
                      </div>
                      <button
                        onClick={e => { e.stopPropagation(); removeQuestion(q.id); }}
                        className="p-1 hover:bg-destructive/10 rounded transition-colors flex-shrink-0"
                      >
                        <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                      </button>
                    </div>
                  </motion.div>

                  {/* Connector */}
                  {i < questions.length - 1 && (
                    <div className="flex justify-center">
                      <div className="w-0.5 h-4 bg-border" />
                    </div>
                  )}
                </div>
              );
            })}

            <button
              onClick={() => addQuestion("text")}
              className="w-full border-2 border-dashed border-border rounded-xl p-4 text-muted-foreground hover:border-primary/30 hover:text-primary transition-colors flex items-center justify-center gap-2 text-sm mt-3"
            >
              <Plus className="w-4 h-4" /> Add question
            </button>
          </div>
        </div>

        {/* ── Right panel: config + preview ── */}
        <div className="w-[420px] bg-card border-l border-border flex-shrink-0 flex flex-col overflow-hidden">
          {selected ? (
            /* ── Config panel ── */
            <div className="flex-1 overflow-auto p-5">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-pixel text-[9px] text-muted-foreground flex items-center gap-2">
                  <Settings2 className="w-3 h-3" /> QUESTION CONFIG
                </h3>
                <button onClick={() => setSelectedId(null)} className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Question text */}
              <div className="space-y-4">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1.5 block">Question Text</Label>
                  <Input
                    value={selected.text}
                    onChange={e => updateQuestion(selected.id, { text: e.target.value })}
                    className="bg-muted border-border text-sm"
                  />
                </div>

                {/* Type display */}
                <div>
                  <Label className="text-xs text-muted-foreground mb-1.5 block">Type</Label>
                  <div className="flex items-center gap-2 text-sm text-foreground capitalize bg-muted px-3 py-2 rounded-md border border-border">
                    {(() => { const Icon = getTypeIcon(selected.type); return <Icon className={`w-4 h-4 ${getTypeColor(selected.type)}`} />; })()}
                    {selected.type === "multi" ? "Multi-Select" : selected.type}
                  </div>
                </div>

                {/* Toggles */}
                <div className="flex items-center justify-between">
                  <Label className="text-xs text-muted-foreground">Required</Label>
                  <Switch
                    checked={selected.required}
                    onCheckedChange={v => updateQuestion(selected.id, { required: v })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label className="text-xs text-muted-foreground">Skippable (type "skip")</Label>
                  <Switch
                    checked={selected.skippable}
                    onCheckedChange={v => updateQuestion(selected.id, { skippable: v })}
                  />
                </div>

                {/* Validation for text */}
                {(selected.type === "text" || selected.type === "url" || selected.type === "email") && (
                  <div>
                    <Label className="text-xs text-muted-foreground mb-1.5 block">Validation</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-[10px] text-muted-foreground">Min length</span>
                        <Input
                          type="number"
                          value={selected.validation?.min ?? ""}
                          onChange={e => updateQuestion(selected.id, {
                            validation: { ...selected.validation, min: parseInt(e.target.value) || undefined }
                          })}
                          className="bg-muted border-border text-xs h-8"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-muted-foreground">Max length</span>
                        <Input
                          type="number"
                          value={selected.validation?.max ?? ""}
                          onChange={e => updateQuestion(selected.id, {
                            validation: { ...selected.validation, max: parseInt(e.target.value) || undefined }
                          })}
                          className="bg-muted border-border text-xs h-8"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Options for select/multi */}
                {(selected.type === "select" || selected.type === "multi") && (
                  <div>
                    <Label className="text-xs text-muted-foreground mb-2 block">
                      Options ({selected.options.length})
                    </Label>
                    <div className="space-y-2">
                      {selected.options.map((opt, oi) => (
                        <div key={opt.id} className="flex items-center gap-2">
                          <Input
                            value={opt.emoji ?? ""}
                            onChange={e => {
                              setQuestions(prev => prev.map(q =>
                                q.id === selected.id
                                  ? { ...q, options: q.options.map(o => o.id === opt.id ? { ...o, emoji: e.target.value } : o) }
                                  : q
                              ));
                            }}
                            className="bg-muted border-border text-xs h-8 w-12 text-center"
                            placeholder="😀"
                          />
                          <Input
                            value={opt.label}
                            onChange={e => updateOption(selected.id, opt.id, e.target.value)}
                            className="bg-muted border-border text-xs h-8 flex-1"
                          />
                          <button
                            onClick={() => removeOption(selected.id, opt.id)}
                            className="p-1 hover:bg-destructive/10 rounded"
                          >
                            <X className="w-3 h-3 text-muted-foreground hover:text-destructive" />
                          </button>
                        </div>
                      ))}
                      <button
                        onClick={() => addOption(selected.id)}
                        className="w-full text-xs text-muted-foreground hover:text-primary py-1.5 border border-dashed border-border rounded hover:border-primary/30 transition-colors"
                      >
                        + Add option
                      </button>
                    </div>

                    {/* Conditional branching */}
                    {selected.type === "select" && (
                      <div className="mt-4 pt-4 border-t border-border">
                        <Label className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
                          <GitBranch className="w-3 h-3 text-secondary" /> Conditional Branches
                        </Label>
                        <p className="text-[10px] text-muted-foreground mb-3">
                          When a specific option is chosen, show a follow-up question (like "Other → describe your role").
                        </p>
                        <div className="space-y-2">
                          {selected.options.map(opt => {
                            const existingBranch = selected.branches.find(b => b.triggerOptionId === opt.id);
                            return (
                              <div key={opt.id} className="flex items-center gap-2 text-xs">
                                <span className="text-muted-foreground truncate w-24" title={opt.label}>
                                  {opt.emoji} {opt.label}
                                </span>
                                <span className="text-muted-foreground">→</span>
                                <select
                                  value={existingBranch?.targetQuestionId ?? ""}
                                  onChange={e => {
                                    const val = e.target.value;
                                    if (val) {
                                      setQuestions(prev => prev.map(q => {
                                        if (q.id !== selected.id) return q;
                                        const filtered = q.branches.filter(b => b.triggerOptionId !== opt.id);
                                        return { ...q, branches: [...filtered, { triggerOptionId: opt.id, targetQuestionId: val }] };
                                      }));
                                    } else {
                                      setQuestions(prev => prev.map(q =>
                                        q.id === selected.id
                                          ? { ...q, branches: q.branches.filter(b => b.triggerOptionId !== opt.id) }
                                          : q
                                      ));
                                    }
                                  }}
                                  className="flex-1 bg-muted border border-border rounded px-2 py-1 text-foreground text-xs"
                                >
                                  <option value="">No branch</option>
                                  {questions.filter(q => q.id !== selected.id).map(q => (
                                    <option key={q.id} value={q.id}>
                                      {q.text.slice(0, 30)}{q.text.length > 30 ? "…" : ""}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* ── Live Preview ── */
            <div className="flex-1 overflow-auto p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-pixel text-[9px] text-muted-foreground flex items-center gap-2">
                  <Eye className="w-3 h-3" /> LIVE PREVIEW
                </h3>
                <button
                  onClick={resetPreview}
                  className="text-[10px] text-muted-foreground hover:text-primary transition-colors"
                >
                  Reset
                </button>
              </div>

              {/* Discord-style preview */}
              <div className="bg-[hsl(var(--background))] rounded-xl border border-border overflow-hidden">
                {/* Title bar */}
                <div className="bg-[hsl(var(--muted))] px-3 py-2 flex items-center gap-2 border-b border-border">
                  <div className="w-2.5 h-2.5 rounded-full bg-destructive" />
                  <div className="w-2.5 h-2.5 rounded-full bg-accent" />
                  <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                  <span className="text-[10px] text-muted-foreground ml-1">Direct Message</span>
                </div>

                {/* Chat */}
                <div className="p-3 space-y-2.5 min-h-[350px] max-h-[450px] overflow-auto">
                  {/* Welcome */}
                  <PreviewMessage from="bot" text="👋 Welcome! Let's get you set up." />

                  {visibleQuestions.map((q, i) => {
                    const answer = previewAnswers[q.id];
                    const isActive = i === previewStep;
                    const isPast = i < previewStep;

                    if (i > previewStep) return null;

                    return (
                      <div key={q.id}>
                        <PreviewMessage from="bot" text={q.text}>
                          {(q.type === "select" || q.type === "multi") && isActive && (
                            <div className="mt-2 flex flex-wrap gap-1">
                              {q.options.map(opt => (
                                <button
                                  key={opt.id}
                                  onClick={() => handlePreviewAnswer(opt.id)}
                                  className="text-[10px] bg-[hsl(var(--muted))] hover:bg-primary/20 px-2 py-1 rounded border border-border hover:border-primary/40 transition-colors"
                                >
                                  {opt.emoji && `${opt.emoji} `}{opt.label}
                                </button>
                              ))}
                            </div>
                          )}
                          {(q.type === "text" || q.type === "url" || q.type === "email") && isActive && (
                            <div className="mt-2 flex gap-1">
                              <input
                                placeholder={q.type === "email" ? "name@example.com" : q.type === "url" ? "https://..." : "Type your answer..."}
                                className="text-[10px] bg-[hsl(var(--muted))] px-2 py-1 rounded border border-border flex-1 text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/40"
                                onKeyDown={e => {
                                  if (e.key === "Enter" && (e.target as HTMLInputElement).value) {
                                    handlePreviewAnswer((e.target as HTMLInputElement).value);
                                    (e.target as HTMLInputElement).value = "";
                                  }
                                }}
                              />
                            </div>
                          )}
                          {q.skippable && isActive && (
                            <button
                              onClick={() => handlePreviewAnswer("skip")}
                              className="text-[10px] text-muted-foreground hover:text-primary mt-1 underline"
                            >
                              skip
                            </button>
                          )}
                        </PreviewMessage>
                        {(isPast || answer) && answer && (
                          <PreviewMessage from="user" text={
                            answer === "skip" ? "skip" :
                            q.options.find(o => o.id === answer)
                              ? `${q.options.find(o => o.id === answer)!.emoji ?? ""} ${q.options.find(o => o.id === answer)!.label}`
                              : answer
                          } />
                        )}
                      </div>
                    );
                  })}

                  {previewStep >= visibleQuestions.length && (
                    <PreviewMessage from="bot" text="✅ You're all set! Welcome aboard." isSuccess />
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ── Preview message component ──────────────────────────────
const PreviewMessage = ({
  from, text, isSuccess, children
}: {
  from: "bot" | "user"; text: string; isSuccess?: boolean; children?: React.ReactNode;
}) => (
  <motion.div
    initial={{ opacity: 0, y: 6 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.2 }}
    className={`flex items-start gap-2 ${from === "user" ? "justify-end" : ""}`}
  >
    {from === "bot" && (
      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
        <BouncerMascot size={18} animate={false} pose="arms-crossed" />
      </div>
    )}
    <div className={`px-2.5 py-1.5 rounded-lg text-[11px] max-w-[250px] ${
      from === "bot"
        ? isSuccess
          ? "bg-primary/20 text-primary border border-primary/30"
          : "bg-[hsl(var(--muted))] text-foreground"
        : "bg-[#5865f2] text-foreground"
    }`}>
      {text}
      {children}
    </div>
  </motion.div>
);

export default FlowBuilder;
