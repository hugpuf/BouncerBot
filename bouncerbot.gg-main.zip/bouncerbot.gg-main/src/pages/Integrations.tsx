import { motion } from "framer-motion";
import { Navbar } from "@/components/landing/Navbar";
import { Button } from "@/components/ui/button";
import { Webhook, Table2, Database, Zap, Globe } from "lucide-react";

const integrations = [
  { name: "Webhook", desc: "Send JSON payloads to any endpoint", icon: Webhook, connected: true, color: "text-mint" },
  { name: "Google Sheets", desc: "Sync responses to a spreadsheet", icon: Table2, connected: true, color: "text-baby-blue" },
  { name: "Airtable", desc: "Push data to your Airtable base", icon: Database, connected: false, color: "text-lavender", vip: true },
  { name: "Notion", desc: "Create entries in Notion databases", icon: Globe, connected: false, color: "text-peach", vip: true },
  { name: "Zapier", desc: "Connect to 5,000+ apps", icon: Zap, connected: false, color: "text-pale-yellow" },
];

const Integrations = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16 container mx-auto px-6 max-w-3xl">
        <h1 className="font-pixel text-lg text-foreground mb-2">The Back Office</h1>
        <p className="text-sm text-muted-foreground mb-8">Connect your data destinations.</p>

        <div className="space-y-4">
          {integrations.map((int, i) => (
            <motion.div
              key={int.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className="bg-card rounded-xl p-5 border border-border flex items-center justify-between"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                  <int.icon className={`w-5 h-5 ${int.color}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-sm text-foreground">{int.name}</p>
                    {int.vip && (
                      <span className="font-pixel text-[7px] px-1.5 py-0.5 rounded bg-lavender/10 text-lavender">VIP</span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{int.desc}</p>
                </div>
              </div>
              <Button
                variant={int.connected ? "outline" : "default"}
                size="sm"
                className={int.connected ? "text-mint border-mint/30" : "gradient-mint-lavender text-primary-foreground"}
              >
                {int.connected ? "Connected" : "Connect"}
              </Button>
            </motion.div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Integrations;
