import { BouncerMascot } from "@/components/BouncerMascot";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-6 px-6 text-center">
      <BouncerMascot pose="pointing" size={160} />
      <h1 className="font-pixel text-2xl md:text-3xl text-foreground">Wrong door.</h1>
      <p className="text-muted-foreground max-w-sm">
        This page doesn't exist. The bouncer is pointing you back to the entrance.
      </p>
      <Link to="/">
        <Button className="gradient-mint-lavender text-primary-foreground font-pixel text-[10px] px-6 py-5">
          Back to the entrance
        </Button>
      </Link>
    </div>
  );
};

export default NotFound;
