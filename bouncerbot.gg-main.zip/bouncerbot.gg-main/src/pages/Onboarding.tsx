import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { BouncerMascot } from "@/components/BouncerMascot";
import { ChevronRight, ChevronLeft } from "lucide-react";
import { StepAddServer } from "@/components/onboarding/StepAddServer";
import { StepPickTemplate } from "@/components/onboarding/StepPickTemplate";
import { StepDataDestination } from "@/components/onboarding/StepDataDestination";
import { StepGoLive } from "@/components/onboarding/StepGoLive";

const STEPS = [
  { id: "welcome", label: "Welcome" },
  { id: "server", label: "Add bot" },
  { id: "template", label: "Template" },
  { id: "destination", label: "Destination" },
  { id: "golive", label: "Go live" },
];

const Onboarding = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [serverName, setServerName] = useState("");
  const [selectedFlow, setSelectedFlow] = useState<string | null>(null);
  const [selectedDest, setSelectedDest] = useState<string | null>(null);
  const [webhookUrl, setWebhookUrl] = useState("");
  const [isLive, setIsLive] = useState(false);

  const canNext = () => {
    if (step === 1) return serverName.length > 0;
    if (step === 2) return selectedFlow !== null;
    // Step 3 (destination) is optional — skip allowed
    return true;
  };

  const totalProgressSteps = 4; // excluding welcome
  const progressStep = step - 1; // 0-indexed from step 1

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        {/* Progress bar — visible on steps 1-4 */}
        {step >= 1 && (
          <div className="flex items-center gap-1 mb-8">
            {Array.from({ length: totalProgressSteps }).map((_, i) => (
              <div
                key={i}
                className={`h-1 flex-1 rounded-full transition-colors duration-300 ${
                  i <= progressStep ? "bg-primary" : "bg-muted"
                }`}
              />
            ))}
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.25 }}
            className="bg-card rounded-2xl border border-border p-8 md:p-12"
          >
            {/* Step 0: Welcome */}
            {step === 0 && (
              <div className="text-center space-y-6">
                <BouncerMascot pose="nod" size={80} />
                <h1 className="font-pixel text-lg text-foreground">Let's set up your door.</h1>
                <p className="text-muted-foreground max-w-md mx-auto">
                  In 60 seconds you'll have a working onboarding bot that captures member data and sends it wherever you need.
                </p>
                <Button
                  onClick={() => setStep(1)}
                  className="gradient-mint-lavender text-primary-foreground font-pixel text-[10px] px-8 py-5"
                >
                  Let's go <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            )}

            {/* Step 1: Add server */}
            {step === 1 && (
              <StepAddServer serverName={serverName} onServerSelect={setServerName} />
            )}

            {/* Step 2: Pick template */}
            {step === 2 && (
              <StepPickTemplate selectedFlow={selectedFlow} onSelect={setSelectedFlow} />
            )}

            {/* Step 3: Data destination */}
            {step === 3 && (
              <StepDataDestination
                selectedDest={selectedDest}
                onSelect={setSelectedDest}
                webhookUrl={webhookUrl}
                onWebhookUrlChange={setWebhookUrl}
              />
            )}

            {/* Step 4: Go live */}
            {step === 4 && (
              <StepGoLive
                serverName={serverName}
                templateName={selectedFlow || "custom"}
                questionCount={0}
                destination={selectedDest}
                isLive={isLive}
                onGoLive={() => setIsLive(true)}
                onPreview={() => navigate("/flow-builder")}
                onFinish={() => navigate("/dashboard")}
              />
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation — steps 1-3, and step 4 only when not live */}
        {step >= 1 && step <= 3 && (
          <div className="flex items-center justify-between mt-6">
            <Button
              variant="ghost"
              onClick={() => setStep(s => s - 1)}
              className="text-muted-foreground text-sm"
            >
              <ChevronLeft className="w-4 h-4 mr-1" /> Back
            </Button>
            <Button
              onClick={() => setStep(s => s + 1)}
              disabled={!canNext()}
              className="gradient-mint-lavender text-primary-foreground font-pixel text-[10px] px-6"
            >
              {step === 3 ? "Review" : "Next"} <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        )}

        {step === 4 && !isLive && (
          <div className="flex items-center justify-start mt-6">
            <Button
              variant="ghost"
              onClick={() => setStep(3)}
              className="text-muted-foreground text-sm"
            >
              <ChevronLeft className="w-4 h-4 mr-1" /> Back
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Onboarding;
